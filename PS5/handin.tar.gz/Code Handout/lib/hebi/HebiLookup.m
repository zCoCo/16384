classdef (Sealed) HebiLookup
    % HebiLookup searches the network for modules and forms groups
    %
    %   HebiLookup periodically searches the <a href="matlab:disp(HebiLookup)">network</a> for modules. Available
    %   modules can be combined into groups, which are the basic way to
    %   send commands and retrieve feedback.
    %
    %   By default, the periodic lookup broadcasts on all local interfaces.
    %   If your network does not allow broadcasts or you want to only poll
    %   on certain ip address, you can manually set them, or modify the
    %   default behavior in the <a href="matlab:open('hebi_config')">config script</a>.
    %
    %   HebiLookup Methods (configuration):
    %   setLookupAddresses       - sets the lookup target address [ipv4]
    %   setLookupFrequency       - sets the lookup and info request rate [Hz]
    %   setInitialGroupFeedbackFrequency - sets the group feedback rate [Hz]
    %   setInitialGroupCommandLifetime - sets the group command lifetime [s]
    %   clearModuleList          - clears module list, including 'stale'
    %
    %   HebiLookup Methods (group creation):
    %   newConnectedGroupFromName - groups by connectivity
    %   newConnectedGroupFromMac  - groups by connectivity
    %   newGroupFromFamily        - groups by family and sorts by name
    %   newGroupFromNames         - groups by user defined names
    %   newGroupFromMacs          - groups by hardware mac addresses
    %
    %   Generally there are two ways to address modules, either by their
    %   user-configurable name, or by their hardware defined mac address.
    %   Some modules (e.g. 'Fieldable' types) have knowledge of their
    %   neighbors, which enables grouping based on their connectivity.
    %
    %   Example
    %      % Show Network
    %      display(HebiLookup);
    %
    %   Example
    %      % Create alphabetically ordered group of all modules
    %      group = HebiLookup.newGroupFromFamily('*');
    %
    %      % Create group using names
    %      family = 'Arm';
    %      names = {'SA023'; 'SA032'; 'SA025'};
    %      group = HebiLookup.newGroupFromNames(family, names);
    %
    %      % Create group using mac addresses
    %      macs = {'08:00:7F:9B:67:09'; '08:00:7F:50:BF:45'};
    %      group = HebiLookup.newGroupFromMacs(macs);
    %
    %      % Create a group of connected modules sorted by connectivity
    %      group = HebiLookup.newConnectedGroupFromName('Arm', 'SA023');
    %      group = HebiLookup.newConnectedGroupFromMac('08:00:7F:9B:67:09');
    %
    %   See also HebiGroup
    
    %   Copyright 2014-2016 HEBI Robotics, LLC.
    
    % Static API
    methods(Static)
        
        function this = setLookupAddresses(varargin)
            %setLookupAddresses sets the lookup target address [ipv4]
            %
            %   An address can be any unicast or broadcast ipv4 address.
            %   In most cases, it is best to let the system determine the
            %   correct addresses using '*'. However, if the network does
            %   not support broadcasting, or is otherwise restricted, it
            %   can be necessary to set addresses manually.
            %
            %   The default behavior can be changed in the <a href="matlab:open('hebi_config')">config script</a>.
            %
            %   Example
            %      % Custom addressing
            %      addresses = {
            %          '10.10.10.255'
            %          '192.168.0.255'
            %      };
            %      HebiLookup.setLookupAddresses(addresses);
            %
            %   See also HebiLookup
            javaMethod('setLookupAddresses', HebiLookup.className,  varargin{:});
            this = HebiLookup.wrapper;
        end
        
        function this = setLookupFrequency(varargin)
            % setLookupFrequency sets the lookup request rate in [Hz]
            %
            %   In addition to finding modules on the network, this rate
            %   also affects the rate at which info and (in default mode)
            %   gains of groups get updated.
            %
            %   These requests produce a relatively high load on modules,
            %   so the rate should be kept relatively low. For long running
            %   applications, it can make sense to disable (set to zero)
            %   lookups entirely in order to limit unnecessary traffic.
            %
            %   The default behavior can be changed in the <a href="matlab:open('hebi_config')">config script</a>.
            %
            %   See also HebiLookup
            javaMethod('setLookupFrequency', HebiLookup.className,  varargin{:});
            this = HebiLookup.wrapper;
        end
        
        function this = setInitialGroupFeedbackFrequency(varargin)
            % setInitialGroupFeedbackFrequency sets the group feedback rate [Hz]
            %
            %   This method affects the initial feedback request rate of
            %   newly created groups. It is a convenience method that
            %   avoids having to set the rate individually for every
            %   group.
            %
            %   The default behavior can be changed in the <a href="matlab:open('hebi_config')">config script</a>.
            %
            %   See also HebiLookup, HebiGroup.setFeedbackFrequency
            javaMethod('setInitialGroupFeedbackFrequency', HebiLookup.className,  varargin{:});
            this = HebiLookup.wrapper;
        end
        
        function this = setInitialGroupCommandLifetime(varargin)
            % setInitialGroupCommandLifetime sets the group command lifetime [s]
            %
            %   This method affects the initial command lifetime of newly
            %   created groups. It is a convenience method that avoids
            %   having to set the lifetime individually for every group.
            %
            %   The default behavior can be changed in the <a href="matlab:open('hebi_config')">config script</a>.
            %
            %   See also HebiLookup, HebiGroup.setCommandLifetime
            javaMethod('setInitialGroupCommandLifetime', HebiLookup.className,  varargin{:});
            this = HebiLookup.wrapper;
        end
        
        function this = clearModuleList(varargin)
            % clearModuleList clears list of available modules
            %
            %   This method clears the list of available modules that have
            %   been found by the lookup. Doing this can make sense when
            %   there are many modules on the network and the list has
            %   become cluttered with 'stale' modules.
            javaMethod('clearModuleList', HebiLookup.className,  varargin{:});
            this = HebiLookup.wrapper;
        end
        
        function this = clearGroups(varargin)
            % clearGroups disposes all existing groups
            %
            %   This method exists for advanced users. Generally, groups
            %   are disposed automatically, and this method does not need
            %   to be called.
            javaMethod('clearGroups', HebiLookup.className,  varargin{:});
            this = HebiLookup.wrapper;
        end
        
        function group = newGroupFromFamily(varargin)
            % newGroupFromFamily groups by family and sorts by name
            %
            %   This method groups all modules that match the selected
            %   family, and orders them alphabetically by their name.
            %
            %   The family may include wildcard characters (*,?)
            %
            %   Example
            %      % Create group of all modules of any group
            %      group = HebiLookup.newGroupFromFamily('*');
            %
            %      % Create group of all modules in a certain group
            %      group = HebiLookup.newGroupFromFamily('Arm');
            %
            %   See also HebiLookup, HebiGroup
            group = HebiGroup(javaMethod('newGroupFromFamily', HebiLookup.className,  varargin{:}));
        end
        
        function group = newGroupFromNames(varargin)
            % newGroupFromNames groups by user defined names
            %
            %   This method groups modules by their specified names and
            %   family. The family may be a single family for all modules,
            %   and may include wildcard characters (*,?).
            %
            %   Example
            %      % Group modules using a family wildcard
            %      family = 'Arm?';
            %      names = {
            %          'SA023'
            %          'SA032'
            %          'SA025'
            %      };
            %      group = HebiLookup.newGroupFromNames(family, names);
            %
            %   Example
            %      % Group modules with different families
            %      families = {
            %          'Arm1'
            %          'Arm2'
            %          'Arm3'
            %      };
            %      names = {
            %          'SA023'
            %          'SA032'
            %          'SA025'
            %      };
            %      group = HebiLookup.newGroupFromNames(families, names);
            %
            %   See also HebiLookup, HebiGroup
            group = HebiGroup(javaMethod('newGroupFromNames', HebiLookup.className,  varargin{:}));
        end
        
        function group = newGroupFromMacs(varargin)
            % newGroupFromMacs groups by hardware mac addresses
            %
            %   This method groups modules by their specified mac
            %   addresses.
            %
            %   Example
            %      macs = {
            %          '08:00:7F:9B:67:09'
            %          '08:00:7F:50:BF:45'
            %      };
            %      group = HebiLookup.newGroupFromMacs(macs);
            %
            %   See also HebiLookup, HebiGroup
            group = HebiGroup(javaMethod('newGroupFromMacs', HebiLookup.className,  varargin{:}));
        end
        
        function group = newConnectedGroupFromName(varargin)
            % newConnectedGroupFromName groups by connectivity
            %
            %   This method groups all modules that are connected to the
            %   the module with the specified name, and orders them by
            %   their connectivity (proximal to distal).
            %
            %   Note that not all module types support this.
            %
            %   Example
            %      family = 'SnakeMonster';
            %      name = 'SA023';
            %      group = HebiLookup.newConnectedGroupFromName(family, name);
            %
            %   See also HebiLookup, HebiGroup
            group = HebiGroup(javaMethod('newConnectedGroupFromName', HebiLookup.className,  varargin{:}));
        end
        
        function group = newConnectedGroupFromMac(varargin)
            % newConnectedGroupFromMac groups by connectivity
            %
            %   This method groups all modules that are connected to the
            %   the module with the specified mac address, and orders them by
            %   their connectivity (proximal to distal).
            %
            %   Note that not all module types support this.
            %
            %   Example
            %      mac = '08:00:7F:9B:67:09';
            %      group = HebiLookup.newConnectedGroupFromMac(mac);
            %
            %   See also HebiLookup, HebiGroup
            group = HebiGroup(javaMethod('newConnectedGroupFromMac', HebiLookup.className,  varargin{:}));
        end
        
    end
    
    % Static objects for delegation
    properties(Constant, Access = private, Hidden = true)
        className = HebiLookup.initOnce();
        wrapper = HebiLookup();
    end
    
    methods(Access = private, Static, Hidden = true)
        function fullName = initOnce()
            % Load library and config
            fullName = hebi_load('HebiLookup');
            config = hebi_config('HebiLookup');
            
            % Set up lookup parameters
            javaMethod('setLookupAddresses', fullName,  ...
                config.defaultLookupAddresses);
            javaMethod('setLookupFrequency', fullName,  ...
                config.defaultLookupFrequency);
            javaMethod('setInitialGroupFeedbackFrequency', fullName,  ...
                config.defaultInitialGroupFeedbackFrequency);
            javaMethod('setInitialGroupCommandLifetime', fullName,  ...
                config.defaultInitialGroupCommandLifetime);
            
            % Add a pause on first call so that the lookup has some
            % time to find modules
            pause(config.initialNetworkLookupPause);
        end
    end
    
    % Non-API Methods for MATLAB compliance
    methods(Access = public, Hidden = true)
        
        function this = HebiLookup
            % constructor
        end
        
        function disp(this)
            % custom display
            disp(javaObject(HebiLookup.className));
        end
        
    end
    
    % Non-API Static methods for MATLAB compliance
    methods(Access = public, Static, Hidden = true)
        
        function varargout = methods(varargin)
            instance = javaObject(HebiLookup.className);
            switch nargout
                case 0
                    methods(instance, varargin{:});
                    varargout = {};
                otherwise
                    varargout{:} = methods(instance, varargin{:});
            end
        end
        
        function varargout = fields(varargin)
            instance = javaObject(HebiLookup.className);
            switch nargout
                case 0
                    fields(instance, varargin{:});
                    varargout = {};
                otherwise
                    varargout{:} = fields(instance, varargin{:});
            end
        end
        
    end
    
end