function [] = setup()
currentDir = fileparts(mfilename('fullpath'));

% Libraries
addpath(fullfile(currentDir , 'lib', 'hebi'));

end
