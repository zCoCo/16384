%{
Note about files:
    - To run project demo, execute CapstoneDemo.m
    -
    - Primary files are:
        Data and Control
            DHP
            Robot3D
            RobotController
        Planning
            Trajectory
            CJT
            JointTrajectory
        Util
            Clock
    -
    - Everything else is for testing.
Author: Connor W. Colombo
Date: 12/13-2018
%}