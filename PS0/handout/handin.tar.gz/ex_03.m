%==============%
% Excercise 03 %
%==============%
function R = ex_03(A, B)
    R = A*B*A*B;
end